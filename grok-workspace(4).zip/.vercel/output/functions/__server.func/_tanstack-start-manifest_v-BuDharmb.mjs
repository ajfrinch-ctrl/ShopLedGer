//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BuDharmb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/collections",
			"/customers",
			"/expenses",
			"/login",
			"/more",
			"/my-dues",
			"/orders",
			"/profile",
			"/profit-loss",
			"/purchases",
			"/reports",
			"/sales",
			"/stock"
		],
		preloads: [
			"/assets/index-DhR3fy2H.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/createLucideIcon-fqRPTsux.js",
			"/assets/link-DH0ZZ8Uj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DhR3fy2H.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C16nDzib.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/calendar-days-BrK_8eWf.js",
			"/assets/chart-column-DhrhAnHN.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/trending-up-C9INpQ_P.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/collections": {
		filePath: "/workspace/src/routes/collections.tsx",
		children: void 0,
		preloads: [
			"/assets/collections-DTOq9Yp6.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/customers": {
		filePath: "/workspace/src/routes/customers.tsx",
		children: ["/customers/$id"],
		preloads: [
			"/assets/customers-C94XaPW4.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/expenses": {
		filePath: "/workspace/src/routes/expenses.tsx",
		children: void 0,
		preloads: [
			"/assets/expenses-DdmbO9NM.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-BywjW0DS.js", "/assets/store-BhKwlEww.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-aa5g2Qq9.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/chart-column-DhrhAnHN.js",
			"/assets/trending-up-C9INpQ_P.js",
			"/assets/users-D0ZyBBT3.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/my-dues": {
		filePath: "/workspace/src/routes/my-dues.tsx",
		children: void 0,
		preloads: [
			"/assets/my-dues-DjKZE0N0.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/orders": {
		filePath: "/workspace/src/routes/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-CE3WNN_W.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/receipt-modal-Cb0W_sXR.js",
			"/assets/minus-0sHFolB9.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-DTuDvSN5.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/profit-loss": {
		filePath: "/workspace/src/routes/profit-loss.tsx",
		children: void 0,
		preloads: [
			"/assets/profit-loss-DezLzbqM.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/purchases": {
		filePath: "/workspace/src/routes/purchases.tsx",
		children: void 0,
		preloads: [
			"/assets/purchases-qFMjlbIa.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/reports": {
		filePath: "/workspace/src/routes/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DlilJcVT.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/calendar-days-BrK_8eWf.js",
			"/assets/trending-up-C9INpQ_P.js",
			"/assets/users-D0ZyBBT3.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/sales": {
		filePath: "/workspace/src/routes/sales.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-BcUk4933.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/receipt-modal-Cb0W_sXR.js",
			"/assets/minus-0sHFolB9.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/stock": {
		filePath: "/workspace/src/routes/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-bLrtPj13.js",
			"/assets/app-shell-DmJgr6E8.js",
			"/assets/plus-DBU3XMg5.js",
			"/assets/store-BhKwlEww.js"
		]
	},
	"/customers/$id": {
		filePath: "/workspace/src/routes/customers.$id.tsx",
		children: void 0,
		preloads: ["/assets/customers._id-CEMzMIcA.js", "/assets/receipt-modal-Cb0W_sXR.js"]
	}
} });
//#endregion
export { tsrStartManifest };
