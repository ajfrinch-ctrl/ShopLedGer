import { S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as roleLabel, g as useShop, n as SHOP } from "./store-BntNszej.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-Cs7bxwOL.js
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const user = useShop((s) => s.user);
	const logout = useShop((s) => s.logout);
	const resetDemo = useShop((s) => s.resetDemo);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, { title: "আমার প্রোফাইল" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-card p-5 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: SHOP.logo,
						alt: "",
						className: "mx-auto size-16 rounded-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg font-bold",
						children: user?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							roleLabel(user?.role),
							" • ",
							user?.phone
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: SHOP.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: SHOP.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: SHOP.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: SHOP.phones.join(" • ")
					})
				]
			}),
			user?.role === "owner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					resetDemo();
					toast.success("ডেমো ডাটা ফিরিয়ে আনা হয়েছে");
				},
				className: "w-full rounded-md border border-line bg-card py-3 text-sm font-semibold",
				children: "ডেমো হিসাব রিসেট করুন"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					logout();
					navigate({ to: "/login" });
				},
				className: "w-full rounded-md bg-danger/10 py-3 text-sm font-semibold text-danger",
				children: "লগআউট"
			})
		]
	})] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilePage, {}) }) });
//#endregion
export { SplitComponent as component };
