import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, g as useShop, h as todayKey, i as bnDate, l as money, m as supplierDue, o as canManage, r as allCustomerDues } from "./store-BntNszej.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/collections-C2QxEdzr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CollectionsPage() {
	const user = useShop((s) => s.user);
	const customers = useShop((s) => s.customers);
	const sales = useShop((s) => s.sales);
	const purchases = useShop((s) => s.purchases);
	const collections = useShop((s) => s.collections);
	const addCollection = useShop((s) => s.addCollection);
	const showBuy = canManage(user?.role);
	const [tab, setTab] = (0, import_react.useState)("customer");
	const [pick, setPick] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)(0);
	const dues = (0, import_react.useMemo)(() => allCustomerDues(customers, sales, collections), [
		customers,
		sales,
		collections
	]);
	const suppliers = (0, import_react.useMemo)(() => {
		return [...new Set(purchases.map((p) => p.supplier))].map((name) => ({
			name,
			due: supplierDue(name, purchases, collections)
		})).filter((s) => s.due > .5).sort((a, b) => b.due - a.due);
	}, [purchases, collections]);
	const recent = collections.filter((c) => tab === "customer" ? c.kind === "customer" : c.kind === "supplier");
	const save = () => {
		if (!pick || amount <= 0) return toast.error("পরিমাণ দিন");
		addCollection({
			date: todayKey(),
			partyId: pick.id,
			partyName: pick.name,
			kind: tab,
			amount: Math.min(amount, pick.due),
			method: "নগদ"
		});
		toast.success("সংরক্ষণ হয়েছে");
		setPick(null);
		setAmount(0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "বাকি আদায়",
			subtitle: "ক্রেতার পাওনা ও সাপ্লায়ার দেনা"
		}),
		showBuy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-3 grid grid-cols-2 rounded-md bg-mint-2 p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("customer"),
				className: `rounded-sm py-2 text-sm font-semibold ${tab === "customer" ? "bg-card text-primary" : "text-muted"}`,
				children: "ক্রেতা"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("supplier"),
				className: `rounded-sm py-2 text-sm font-semibold ${tab === "supplier" ? "bg-card text-primary" : "text-muted"}`,
				children: "সাপ্লায়ার"
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3",
			children: [tab === "customer" ? dues.map(({ customer, due }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setPick({
						id: customer.id,
						name: customer.name,
						due
					});
					setAmount(due);
				},
				className: "flex w-full items-center justify-between border-b border-line px-4 py-3.5 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: customer.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted",
					children: customer.phone
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tabular text-danger",
					children: money(due)
				})]
			}, customer.id)) : suppliers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setPick({
						id: s.name,
						name: s.name,
						due: s.due
					});
					setAmount(s.due);
				},
				className: "flex w-full items-center justify-between border-b border-line px-4 py-3.5 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: s.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tabular text-warn",
					children: money(s.due)
				})]
			}, s.name)), (tab === "customer" ? dues : suppliers).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-sm text-muted",
				children: "কোনো বাকি নেই"
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "mt-5 px-4 text-sm font-bold",
			children: [
				"সাম্প্রতিক আদায় (",
				bnNum(recent.length),
				")"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1",
			children: recent.slice(0, 12).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: c.partyName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] text-muted",
					children: [
						bnDate(c.date),
						" • ",
						c.method
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tabular text-primary",
					children: money(c.amount)
				})]
			}, c.id))
		}),
		tab === "customer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-3 text-center text-xs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/customers",
				className: "font-semibold text-primary",
				children: "সব ক্রেতার খাতা"
			})
		}) : null,
		pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end bg-fg/50 p-3 sm:items-center sm:justify-center",
			onClick: () => setPick(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md rounded-xl bg-card p-4",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: pick.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: ["বাকি ", money(pick.due)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						value: amount || "",
						onChange: (e) => setAmount(Number(e.target.value) || 0),
						className: "mt-3 w-full rounded-md border border-line px-3 py-2.5 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: save,
						className: "mt-3 w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
						children: tab === "customer" ? "আদায় সংরক্ষণ" : "পরিশোধ সংরক্ষণ"
					})
				]
			})
		}) : null
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionsPage, {}) }) });
//#endregion
export { SplitComponent as component };
