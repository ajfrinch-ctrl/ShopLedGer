import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as useShop, n as SHOP, t as DEMO_ACCOUNTS } from "./store-BntNszej.mjs";
import { C as EyeOff, S as Eye, m as Phone, y as Lock } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DZOjcA2S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROLE_TONE = {
	owner: "border-warn/30 bg-mint text-primary-dark",
	salesman: "border-info/20 bg-card text-info",
	customer: "border-line bg-bg text-fg"
};
function LoginPage() {
	const [phone, setPhone] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)(false);
	const login = useShop((s) => s.login);
	const error = useShop((s) => s.loginError);
	const user = useShop((s) => s.user);
	const hydrated = useShop((s) => s.hydrated);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (hydrated && user) navigate({ to: "/" });
	}, [
		hydrated,
		user,
		navigate
	]);
	const submit = (e) => {
		e.preventDefault();
		if (login(phone, password)) navigate({ to: "/" });
	};
	const fill = (p, pass, instant) => {
		setPhone(p);
		setPassword(pass);
		if (instant && login(p, pass)) navigate({ to: "/" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col items-center justify-center overflow-x-hidden overflow-y-auto bg-primary px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 -top-20 size-52 rounded-full bg-card/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-16 -left-16 size-40 rounded-full bg-card/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mb-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mb-3 flex size-20 items-center justify-center rounded-xl bg-card shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: SHOP.logo,
							alt: "",
							className: "size-16 rounded-lg object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold leading-snug text-card",
						children: SHOP.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-medium text-mint-2",
						children: SHOP.tagline
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 w-full max-w-sm rounded-xl bg-card p-6 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold",
							children: "লগইন করুন"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "আপনার অ্যাকাউন্টে প্রবেশ করুন"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-semibold",
								children: ["আইডি অথবা মোবাইল নম্বর", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mt-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
										size: 18,
										className: "absolute left-3 top-1/2 -translate-y-1/2 text-primary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: phone,
										onChange: (e) => setPhone(e.target.value.slice(0, 30)),
										placeholder: "01XXXXXXXXX",
										autoComplete: "tel",
										className: "w-full rounded-md border-2 border-line py-3 pl-10 pr-4 text-base outline-none focus:border-primary"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-semibold",
								children: ["পাসওয়ার্ড", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mt-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
											size: 18,
											className: "absolute left-3 top-1/2 -translate-y-1/2 text-primary"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: show ? "text" : "password",
											value: password,
											onChange: (e) => setPassword(e.target.value),
											placeholder: "পাসওয়ার্ড লিখুন",
											autoComplete: "current-password",
											className: "w-full rounded-md border-2 border-line py-3 pl-10 pr-12 text-base outline-none focus:border-primary"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": show ? "লুকান" : "দেখান",
											onClick: () => setShow((v) => !v),
											className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted",
											children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
										})
									]
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-center text-sm text-danger",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: !phone.trim() || password.length < 4,
								className: "w-full rounded-md bg-primary py-3.5 text-base font-bold text-card shadow-[0_8px_20px_rgba(4,121,90,0.28)] disabled:bg-muted",
								children: "প্রবেশ করুন"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-5 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px flex-1 bg-line" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: "ডেমো অ্যাকাউন্ট"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px flex-1 bg-line" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: DEMO_ACCOUNTS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => fill(a.phone, a.password, true),
							className: `flex w-full min-w-0 items-center justify-between gap-2 rounded-md border px-3 py-2.5 text-left text-sm font-medium ${ROLE_TONE[a.role] ?? ROLE_TONE.owner}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 truncate",
								children: [
									a.role === "owner" ? "মালিক" : a.role === "salesman" ? "কর্মচারী" : "ক্রেতা",
									" — ",
									a.name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 font-mono text-xs opacity-80",
								children: a.phone
							})]
						}, a.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative z-10 mt-6 text-xs text-mint-2",
				children: "অফলাইনেও কাজ করে • ডাটা এই ডিভাইসে সেভ হয়"
			})
		]
	});
}
//#endregion
export { LoginPage as component };
