import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, g as useShop, h as todayKey, i as bnDate, l as money, o as canManage } from "./store-BntNszej.mjs";
import { p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/purchases-CM4lnHK4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PurchasesPage() {
	const user = useShop((s) => s.user);
	const purchases = useShop((s) => s.purchases);
	const products = useShop((s) => s.products);
	const addPurchase = useShop((s) => s.addPurchase);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [productId, setProductId] = (0, import_react.useState)(products[0]?.id ?? "");
	const [qty, setQty] = (0, import_react.useState)(1);
	const [price, setPrice] = (0, import_react.useState)(products[0]?.purchasePrice ?? 0);
	const [supplier, setSupplier] = (0, import_react.useState)("নন্দন ফিড মিলস");
	const [paid, setPaid] = (0, import_react.useState)(0);
	const [date, setDate] = (0, import_react.useState)(todayKey());
	if (!canManage(user?.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-6 text-sm",
		children: "ক্রয় এন্ট্রি মালিক/ব্যবস্থাপকের জন্য।"
	});
	const p = products.find((x) => x.id === productId);
	const total = qty * price;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "ক্রয়",
			subtitle: "সাপ্লায়ার চালান ও স্টক ইন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "flex w-full items-center justify-center gap-2 rounded-md bg-primary py-3 text-sm font-bold text-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), " নতুন ক্রয়"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3",
			children: purchases.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between border-b border-line px-4 py-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: row.productName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] text-muted",
					children: [
						row.supplier,
						" • ",
						bnDate(row.date),
						" • ",
						bnNum(row.quantity),
						" ",
						row.unit
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold tabular",
						children: money(row.total)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-[11px] ${row.total - row.paid > 0 ? "text-danger" : "text-primary"}`,
						children: row.total - row.paid > 0 ? `বাকি ${money(row.total - row.paid)}` : "পরিশোধিত"
					})]
				})]
			}, row.id))
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end bg-fg/50 p-3 sm:items-center sm:justify-center",
			onClick: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md rounded-xl bg-card p-4",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "স্টক ইন"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-semibold",
							children: ["তারিখ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								max: todayKey(),
								value: date,
								onChange: (e) => setDate(e.target.value),
								className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-semibold",
							children: ["পণ্য", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: productId,
								onChange: (e) => {
									setProductId(e.target.value);
									const np = products.find((x) => x.id === e.target.value);
									if (np) setPrice(np.purchasePrice);
								},
								className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm",
								children: products.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: x.id,
									children: x.name
								}, x.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: supplier,
							onChange: (e) => setSupplier(e.target.value),
							placeholder: "সাপ্লায়ার",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-semibold",
								children: ["পরিমাণ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									value: qty,
									onChange: (e) => setQty(Number(e.target.value) || 0),
									className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-semibold",
								children: ["দর", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									value: price,
									onChange: (e) => setPrice(Number(e.target.value) || 0),
									className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-semibold",
							children: ["জমা (৳) — খালি রাখলে পুরোটা বাকি", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								value: paid || "",
								onChange: (e) => setPaid(Number(e.target.value) || 0),
								className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold",
							children: ["মোট ", money(total)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (!p || !qty || !supplier.trim()) return toast.error("সব ঘর পূরণ করুন");
								addPurchase({
									date,
									productId: p.id,
									productName: p.name,
									quantity: qty,
									unit: p.unit,
									purchasePrice: price,
									total,
									supplier: supplier.trim(),
									paid: Math.min(paid, total)
								});
								setOpen(false);
								toast.success("ক্রয় সংরক্ষণ হয়েছে");
							},
							className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
							children: "সংরক্ষণ"
						})
					]
				})]
			})
		}) : null
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchasesPage, {}) }) });
//#endregion
export { SplitComponent as component };
