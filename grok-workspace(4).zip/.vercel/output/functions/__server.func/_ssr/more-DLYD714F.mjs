import { S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as useShop, o as canManage } from "./store-BntNszej.mjs";
import { D as ChevronRight, E as CircleUserRound, O as ChartColumn, T as ClipboardList, a as TrendingUp, c as ShoppingBag, f as Receipt, h as Package, j as Building2, n as Wallet, r as Users, v as LogOut } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-DLYD714F.js
var import_jsx_runtime = require_jsx_runtime();
function MorePage() {
	const user = useShop((s) => s.user);
	const logout = useShop((s) => s.logout);
	const navigate = useNavigate();
	const manage = canManage(user?.role);
	const items = [
		{
			to: "/customers",
			icon: Users,
			label: "ক্রেতা",
			desc: "তালিকা, বাকি ও কেনাকাটার ইতিহাস"
		},
		{
			to: "/orders",
			icon: ClipboardList,
			label: "ক্রেতার অর্ডার",
			desc: "অর্ডার গ্রহণ ও ডেলিভারি → বিক্রি"
		},
		...manage ? [{
			to: "/purchases",
			icon: ShoppingBag,
			label: "ক্রয় এন্ট্রি",
			desc: "সাপ্লাইয়ার চালান"
		}, {
			to: "/expenses",
			icon: Receipt,
			label: "খরচ এন্ট্রি",
			desc: "দোকানের খরচ ও মালিকের টাকা তোলা"
		}] : [],
		{
			to: "/reports",
			icon: ChartColumn,
			label: "রিপোর্ট সেন্টার",
			desc: "বিস্তারিত রিপোর্ট ও স্টেটমেন্ট প্রিভিউ"
		},
		...manage ? [{
			to: "/profit-loss",
			icon: TrendingUp,
			label: "লাভ-ক্ষতি",
			desc: "দৈনিক ও মাসিক নিট লাভ"
		}] : [],
		{
			to: "/stock",
			icon: Package,
			label: "স্টক",
			desc: "পণ্য, সমন্বয়, লো-স্টক"
		},
		...manage ? [{
			to: "/collections",
			icon: Wallet,
			label: "সাপ্লায়ারকে দেনা",
			desc: "পণ্য ক্রয়ের বাকি"
		}] : [],
		{
			to: "/profile",
			icon: CircleUserRound,
			label: "আমার প্রোফাইল",
			desc: "নাম, মোবাইল ও ডেমো রিসেট"
		},
		...user?.role === "owner" ? [{
			to: "/profile",
			icon: Building2,
			label: "শাখা ও প্যাড",
			desc: "প্রধান শাখা • কর্ণফুলী সেলস সেন্টার"
		}] : []
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, { title: "আরও" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 p-4",
		children: [items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: it.to,
			className: "flex items-center gap-3 rounded-lg border border-line bg-card p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-md bg-mint-2 p-2.5 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { size: 20 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: it.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: it.desc
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					size: 16,
					className: "text-muted"
				})
			]
		}, it.to + it.label)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => {
				logout();
				navigate({ to: "/login" });
			},
			className: "mt-4 flex w-full items-center gap-3 rounded-lg border border-line bg-card p-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md bg-bg p-2.5 text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 20 })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "লগআউট"
			})]
		})]
	})] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MorePage, {}) }) });
//#endregion
export { SplitComponent as component };
