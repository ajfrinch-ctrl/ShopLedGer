import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, c as customerDue, g as useShop, l as money } from "./store-BntNszej.mjs";
import { p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/customers-DrIZ-Wma.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CustomersPage() {
	const customers = useShop((s) => s.customers);
	const sales = useShop((s) => s.sales);
	const collections = useShop((s) => s.collections);
	const addCustomer = useShop((s) => s.addCustomer);
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		return customers.map((c) => ({
			c,
			due: customerDue(c.id, sales, collections)
		})).filter((r) => !q.trim() || r.c.name.includes(q) || r.c.phone.includes(q) || r.c.address.includes(q)).sort((a, b) => b.due - a.due);
	}, [
		customers,
		sales,
		collections,
		q
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "ক্রেতা",
			subtitle: `${bnNum(customers.length)} জন খাতা`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 px-4 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "নাম বা মোবাইল",
				className: "flex-1 rounded-md border border-line px-3 py-2.5 text-sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "rounded-md bg-primary px-3 text-card",
				"aria-label": "নতুন ক্রেতা",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2",
			children: rows.map(({ c, due }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/customers/$id",
				params: { id: c.id },
				className: "flex items-center gap-3 border-b border-line px-4 py-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-10 items-center justify-center rounded-full bg-mint-2 text-sm font-bold text-primary",
						children: c.name.slice(0, 1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-[11px] text-muted",
							children: [
								c.phone,
								" ",
								c.address ? `• ${c.address}` : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-sm font-bold tabular ${due > 0 ? "text-danger" : "text-primary"}`,
						children: due > 0 ? money(due) : "ক্লিয়ার"
					})
				]
			}) }, c.id))
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end bg-fg/50 p-3 sm:items-center sm:justify-center",
			onClick: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md rounded-xl bg-card p-4",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "নতুন ক্রেতা"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "নাম",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							placeholder: "মোবাইল",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: address,
							onChange: (e) => setAddress(e.target.value),
							placeholder: "ঠিকানা",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (!name.trim()) return toast.error("নাম দিন");
								addCustomer({
									name: name.trim(),
									phone: phone.trim(),
									address: address.trim()
								});
								setOpen(false);
								setName("");
								setPhone("");
								setAddress("");
								toast.success("ক্রেতা যোগ হয়েছে");
							},
							className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
							children: "সংরক্ষণ"
						})
					]
				})]
			})
		}) : null
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomersPage, {}) }) });
//#endregion
export { SplitComponent as component };
