import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as useShop, h as todayKey, i as bnDate, l as money, o as canManage } from "./store-BntNszej.mjs";
import { p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/expenses-CmviaMpe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATS = [
	"ভাড়া",
	"বিদ্যুৎ",
	"যাতায়াত",
	"বেতন",
	"প্যাকেজিং",
	"অন্যান্য",
	"মালিকের উত্তোলন"
];
function ExpensesPage() {
	const user = useShop((s) => s.user);
	const expenses = useShop((s) => s.expenses);
	const addExpense = useShop((s) => s.addExpense);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [category, setCategory] = (0, import_react.useState)(CATS[0]);
	const [amount, setAmount] = (0, import_react.useState)(0);
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(todayKey());
	if (!canManage(user?.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-6 text-sm",
		children: "খরচ এন্ট্রি মালিক/ব্যবস্থাপকের জন্য।"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "খরচ",
			subtitle: "দোকান খরচ ও মালিকের উত্তোলন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "flex w-full items-center justify-center gap-2 rounded-md bg-primary py-3 text-sm font-bold text-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), " নতুন খরচ"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3",
			children: expenses.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between border-b border-line px-4 py-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: e.category
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] text-muted",
					children: [
						bnDate(e.date),
						" • ",
						e.kind === "owner" ? "মালিকের উত্তোলন" : "দোকান খরচ",
						e.note ? ` • ${e.note}` : ""
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tabular",
					children: money(e.amount)
				})]
			}, e.id))
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end bg-fg/50 p-3 sm:items-center sm:justify-center",
			onClick: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md rounded-xl bg-card p-4",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "খরচ এন্ট্রি"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							max: todayKey(),
							value: date,
							onChange: (e) => setDate(e.target.value),
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm",
							children: CATS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 0,
							value: amount || "",
							onChange: (e) => setAmount(Number(e.target.value) || 0),
							placeholder: "পরিমাণ",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: note,
							onChange: (e) => setNote(e.target.value),
							placeholder: "নোট (ঐচ্ছিক)",
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (!amount) return toast.error("পরিমাণ দিন");
								addExpense({
									date,
									category,
									amount,
									kind: category === "মালিকের উত্তোলন" ? "owner" : "shop",
									note: note.trim() || void 0
								});
								setOpen(false);
								setAmount(0);
								setNote("");
								toast.success("খরচ সংরক্ষণ হয়েছে");
							},
							className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
							children: "সংরক্ষণ"
						})
					]
				})]
			})
		}) : null
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpensesPage, {}) }) });
//#endregion
export { SplitComponent as component };
