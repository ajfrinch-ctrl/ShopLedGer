import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, d as profitSummary, g as useShop, h as todayKey, i as bnDate, l as money, n as SHOP, p as stockOf, r as allCustomerDues, s as canSeeProfit, u as monthStartKey } from "./store-BntNszej.mjs";
import { A as CalendarDays, M as Boxes, T as ClipboardList, a as TrendingUp, c as ShoppingBag, f as Receipt, h as Package, k as CalendarRange, n as Wallet, r as Users, t as X } from "../_libs/lucide-react.mjs";
import { r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-BLgfpNHn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATALOG = [
	{
		kind: "sales",
		label: "বিক্রয় রিপোর্ট",
		desc: "তারিখ অনুযায়ী বিল",
		icon: TrendingUp
	},
	{
		kind: "purchase",
		label: "ক্রয় রিপোর্ট",
		desc: "সাপ্লায়ার চালান",
		icon: ShoppingBag,
		manage: true
	},
	{
		kind: "stock",
		label: "স্টক রিপোর্ট",
		desc: "বর্তমান মজুদ",
		icon: Boxes
	},
	{
		kind: "customerDue",
		label: "ক্রেতার বাকি",
		desc: "পাওনার তালিকা",
		icon: Users
	},
	{
		kind: "collection",
		label: "আদায় রিপোর্ট",
		desc: "বাকি আদায়",
		icon: Wallet
	},
	{
		kind: "expense",
		label: "খরচ রিপোর্ট",
		desc: "দোকান খরচ",
		icon: Receipt,
		manage: true
	},
	{
		kind: "dailyProfit",
		label: "দৈনিক লাভ",
		desc: "আজকের নিট",
		icon: CalendarDays,
		manage: true
	},
	{
		kind: "monthlyProfit",
		label: "মাসিক লাভ",
		desc: "চলতি মাস",
		icon: CalendarRange,
		manage: true
	},
	{
		kind: "product",
		label: "পণ্য রিপোর্ট",
		desc: "বিক্রি অনুযায়ী",
		icon: Package
	},
	{
		kind: "transaction",
		label: "লেনদেন",
		desc: "সব এন্ট্রি",
		icon: ClipboardList
	}
];
function ReportsPage() {
	const user = useShop((s) => s.user);
	const profit = canSeeProfit(user?.role);
	const visible = CATALOG.filter((c) => !c.manage || profit);
	const [kind, setKind] = (0, import_react.useState)(null);
	const [from, setFrom] = (0, import_react.useState)(monthStartKey());
	const [to, setTo] = (0, import_react.useState)(todayKey());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-primary px-4 pt-4 pb-6 text-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-bold",
					children: "রিপোর্ট সেন্টার"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-mint-2",
					children: "বিষয় বাছুন → সময়সীমা দিন → স্টেটমেন্ট দেখুন"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4 -mt-3",
				children: visible.map((def) => {
					const Icon = def.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setKind(def.kind),
						className: "flex w-full items-center gap-3 rounded-lg border border-line bg-card p-4 text-left shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-mint-2 p-2.5 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium",
								children: def.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[11px] text-muted",
								children: def.desc
							})]
						})]
					}, def.kind);
				})
			}),
			kind ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Statement, {
				kind,
				from,
				to,
				setFrom,
				setTo,
				onClose: () => setKind(null)
			}) : null
		]
	});
}
function Statement({ kind, from, to, setFrom, setTo, onClose }) {
	const def = CATALOG.find((c) => c.kind === kind);
	const sales = useShop((s) => s.sales);
	const purchases = useShop((s) => s.purchases);
	const expenses = useShop((s) => s.expenses);
	const collections = useShop((s) => s.collections);
	const products = useShop((s) => s.products);
	const customers = useShop((s) => s.customers);
	const adjustments = useShop((s) => s.adjustments);
	const rows = (0, import_react.useMemo)(() => {
		const inR = (d) => d >= from && d <= to;
		if (kind === "sales") return sales.filter((s) => inR(s.date)).map((s) => [
			s.billNo,
			s.customerName,
			money(s.total)
		]);
		if (kind === "purchase") return purchases.filter((p) => inR(p.date)).map((p) => [
			p.productName,
			p.supplier,
			money(p.total)
		]);
		if (kind === "stock") return products.map((p) => {
			const q = stockOf(p, sales, purchases, adjustments);
			return [
				p.name,
				`${bnNum(q)} ${p.unit}`,
				money(q * p.purchasePrice)
			];
		});
		if (kind === "customerDue") return allCustomerDues(customers, sales, collections).map((d) => [
			d.customer.name,
			d.customer.phone,
			money(d.due)
		]);
		if (kind === "collection") return collections.filter((c) => inR(c.date)).map((c) => [
			c.partyName,
			c.kind === "customer" ? "আদায়" : "পরিশোধ",
			money(c.amount)
		]);
		if (kind === "expense") return expenses.filter((e) => inR(e.date)).map((e) => [
			e.category,
			e.kind === "owner" ? "উত্তোলন" : "খরচ",
			money(e.amount)
		]);
		if (kind === "product") {
			const map = /* @__PURE__ */ new Map();
			for (const s of sales.filter((x) => inR(x.date))) for (const i of s.items) map.set(i.productName, (map.get(i.productName) ?? 0) + i.total);
			return [...map.entries()].sort((a, b) => b[1] - a[1]).map(([n, t]) => [
				n,
				"",
				money(t)
			]);
		}
		if (kind === "transaction") {
			const t = [];
			for (const s of sales.filter((x) => inR(x.date))) t.push([
				s.date,
				`বিক্রি • ${s.customerName}`,
				money(s.total)
			]);
			for (const p of purchases.filter((x) => inR(x.date))) t.push([
				p.date,
				`ক্রয় • ${p.supplier}`,
				money(p.total)
			]);
			for (const e of expenses.filter((x) => inR(x.date))) t.push([
				e.date,
				`খরচ • ${e.category}`,
				money(e.amount)
			]);
			return t.sort((a, b) => a[0] < b[0] ? 1 : -1).map((r) => [
				bnDate(r[0]),
				r[1],
				r[2]
			]);
		}
		return [];
	}, [
		kind,
		from,
		to,
		sales,
		purchases,
		expenses,
		collections,
		products,
		customers,
		adjustments
	]);
	const pl = profitSummary(sales, expenses, kind === "dailyProfit" ? todayKey() : from, kind === "dailyProfit" ? todayKey() : to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-fg/50 p-3 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[92dvh] w-full max-w-md flex-col overflow-hidden rounded-xl bg-card",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-primary-dark",
						children: def.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "প্রিভিউ — চাইলে শেয়ার করুন"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				kind !== "stock" && kind !== "customerDue" && kind !== "dailyProfit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 border-b border-line p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: "rounded-md border border-line px-2 py-2 text-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: "rounded-md border border-line px-2 py-2 text-xs"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: SHOP.logo,
							alt: "",
							className: "mx-auto mb-2 size-12 rounded-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold",
							children: SHOP.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: SHOP.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold",
							children: def.label
						}),
						kind === "dailyProfit" || kind === "monthlyProfit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2 text-left text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "বিক্রি",
									v: money(pl.revenue)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "কস্ট",
									v: money(pl.cogs)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "গ্রস লাভ",
									v: money(pl.gross)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "খরচ",
									v: money(pl.shopExp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "নিট লাভ",
									v: money(pl.net),
									bold: true
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
							className: "mt-3 w-full text-left text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 pr-2",
										children: r[0]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 text-muted",
										children: r[1]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 text-right font-semibold tabular",
										children: r[2]
									})
								]
							}, i)) })
						}),
						!rows.length && kind !== "dailyProfit" && kind !== "monthlyProfit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-6 text-sm text-muted",
							children: "এই সময়ে কোনো ডাটা নেই"
						}) : null
					]
				})
			]
		})
	});
}
function Line({ k, v, bold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between ${bold ? "font-bold text-primary" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular",
			children: v
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsPage, {}) }) });
//#endregion
export { SplitComponent as component };
