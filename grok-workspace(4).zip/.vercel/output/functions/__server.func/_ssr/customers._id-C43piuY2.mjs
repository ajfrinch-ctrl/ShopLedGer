import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as customerDue, g as useShop, h as todayKey, i as bnDate, l as money, n as SHOP } from "./store-BntNszej.mjs";
import { r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-B5XVsHPL.mjs";
import { t as ReceiptModal } from "./receipt-modal-D3JWBUQv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/customers._id-C43piuY2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Profile() {
	const { id } = Route.useParams();
	const customer = useShop((s) => s.customers.find((c) => c.id === id));
	const sales = useShop((s) => s.sales.filter((x) => x.customerId === id));
	const collections = useShop((s) => s.collections.filter((c) => c.kind === "customer" && c.partyId === id));
	const allSales = useShop((s) => s.sales);
	const allCol = useShop((s) => s.collections);
	const addCollection = useShop((s) => s.addCollection);
	const [amount, setAmount] = (0, import_react.useState)(0);
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const due = customer ? customerDue(customer.id, allSales, allCol) : 0;
	const ledger = (0, import_react.useMemo)(() => {
		const rows = [];
		for (const s of sales) rows.push({
			key: s.id,
			date: s.date,
			label: s.billNo,
			debit: s.total,
			credit: s.paid,
			sale: s
		});
		for (const c of collections) rows.push({
			key: c.id,
			date: c.date,
			label: `আদায় • ${c.method}`,
			debit: 0,
			credit: c.amount
		});
		rows.sort((a, b) => a.date < b.date ? -1 : 1);
		let bal = 0;
		return rows.map((r) => {
			bal += r.debit - r.credit;
			return {
				...r,
				bal
			};
		});
	}, [sales, collections]);
	if (!customer) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 text-center text-sm",
		children: ["ক্রেতা পাওয়া যায়নি। ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/customers",
			children: "ফিরে যান"
		})]
	});
	const collect = () => {
		if (amount <= 0) return toast.error("পরিমাণ দিন");
		addCollection({
			date: todayKey(),
			partyId: customer.id,
			partyName: customer.name,
			kind: "customer",
			amount,
			method: "নগদ"
		});
		setAmount(0);
		toast.success("আদায় সংরক্ষণ হয়েছে");
	};
	const wa = customer.phone.replace(/\D/g, "");
	const waText = encodeURIComponent(`${SHOP.name}\nপ্রিয় ${customer.name},\nআপনার বর্তমান বাকি ${money(due)}।\n${SHOP.phones[0]}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-primary p-5 text-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xl font-bold",
						children: customer.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-mint-2",
						children: [
							customer.phone,
							" ",
							customer.address ? `• ${customer.address}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-[11px] text-mint-2",
						children: "বর্তমান বাকি"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-bold tabular",
						children: money(due)
					})
				]
			}),
			due > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm font-semibold",
						children: "বাকি আদায়"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								value: amount || "",
								onChange: (e) => setAmount(Number(e.target.value) || 0),
								placeholder: "পরিমাণ",
								className: "flex-1 rounded-md border border-line px-3 py-2.5 text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setAmount(due),
								className: "rounded-md bg-mint-2 px-3 text-xs font-semibold text-primary",
								children: "সব"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: collect,
								className: "rounded-md bg-primary px-4 text-sm font-bold text-card",
								children: "জমা"
							})
						]
					}),
					wa.length >= 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `https://wa.me/88${wa}?text=${waText}`,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-3 block text-center text-xs font-semibold text-primary",
						children: "WhatsApp-এ তাগাদা পাঠান"
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-5 mb-2 text-sm font-bold",
				children: "খাতা"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl border border-line bg-card",
				children: ledger.length ? ledger.slice().reverse().map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: !r.sale,
					onClick: () => r.sale && setReceipt(r.sale),
					className: "flex w-full items-center justify-between border-b border-line px-4 py-3 text-left last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: r.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: bnDate(r.date)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-sm font-bold tabular ${r.debit ? "text-fg" : "text-primary"}`,
							children: r.debit ? money(r.debit) : `+ ${money(r.credit)}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted tabular",
							children: ["ব্যালেন্স ", money(r.bal)]
						})]
					})]
				}, r.key)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted",
					children: "এখনও কোনো লেনদেন নেই"
				})
			}),
			receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptModal, {
				sale: receipt,
				onClose: () => setReceipt(null)
			}) : null
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Profile, {}) }) });
//#endregion
export { SplitComponent as component };
