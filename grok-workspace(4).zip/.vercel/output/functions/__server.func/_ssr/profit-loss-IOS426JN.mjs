import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as profitSummary, g as useShop, h as todayKey, l as money, s as canSeeProfit, u as monthStartKey } from "./store-BntNszej.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profit-loss-IOS426JN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PLPage() {
	const user = useShop((s) => s.user);
	const sales = useShop((s) => s.sales);
	const expenses = useShop((s) => s.expenses);
	const [tab, setTab] = (0, import_react.useState)("day");
	const [from, setFrom] = (0, import_react.useState)(monthStartKey());
	const [to, setTo] = (0, import_react.useState)(todayKey());
	if (!canSeeProfit(user?.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-6 text-sm",
		children: "লাভ-ক্ষতি শুধু মালিক ও ব্যবস্থাপকের জন্য।"
	});
	const range = tab === "day" ? {
		from: todayKey(),
		to: todayKey()
	} : tab === "month" ? {
		from: monthStartKey(),
		to: todayKey()
	} : {
		from,
		to
	};
	const pl = profitSummary(sales, expenses, range.from, range.to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "লাভ-ক্ষতি",
			subtitle: "বিক্রির মুনাফা থেকে দোকান খরচ বাদ"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-4 mt-3 grid grid-cols-3 rounded-md bg-mint-2 p-1",
			children: [
				["day", "আজ"],
				["month", "মাস"],
				["range", "কাস্টম"]
			].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(k),
				className: `rounded-sm py-2 text-sm font-semibold ${tab === k ? "bg-card text-primary" : "text-muted"}`,
				children: l
			}, k))
		}),
		tab === "range" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-3 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "date",
				value: from,
				onChange: (e) => setFrom(e.target.value),
				className: "rounded-md border border-line px-3 py-2 text-sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "date",
				value: to,
				onChange: (e) => setTo(e.target.value),
				className: "rounded-md border border-line px-3 py-2 text-sm"
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "m-4 space-y-2 rounded-xl border border-line bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "বিক্রি",
					v: pl.revenue
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "পণ্যের কস্ট",
					v: pl.cogs
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "গ্রস লাভ",
					v: pl.gross
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "দোকান খরচ",
					v: pl.shopExp
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-line pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "নিট লাভ",
						v: pl.net,
						big: true
					})
				}),
				pl.ownerDraw ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "pt-2 text-[11px] text-muted",
					children: [
						"মালিকের উত্তোলন ",
						money(pl.ownerDraw),
						" — লাভ থেকে বাদ যায়নি"
					]
				}) : null
			]
		})
	] });
}
function Row({ k, v, big }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: big ? "font-bold" : "text-sm text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `tabular ${big ? "text-xl font-bold text-primary" : "text-sm font-semibold"} ${v < 0 ? "text-danger" : ""}`,
			children: money(v)
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PLPage, {}) }) });
//#endregion
export { SplitComponent as component };
