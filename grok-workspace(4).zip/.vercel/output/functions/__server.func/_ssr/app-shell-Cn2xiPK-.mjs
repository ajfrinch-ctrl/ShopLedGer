import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react, b as useNavigate, f as useRouterState, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as roleLabel, g as useShop, n as SHOP } from "./store-BntNszej.mjs";
import { E as CircleUserRound, T as ClipboardList, _ as Menu, b as LayoutDashboard, h as Package, n as Wallet, s as ShoppingCart, t as X, u as Settings, v as LogOut } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-Cn2xiPK-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function LoadingScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-mint",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 size-10 animate-pulse rounded-xl bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "লোড হচ্ছে..."
			})]
		})
	});
}
function RequireAuth({ children }) {
	const user = useShop((s) => s.user);
	const hydrated = useShop((s) => s.hydrated);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (hydrated && !user) navigate({ to: "/login" });
	}, [
		hydrated,
		user,
		navigate
	]);
	if (!hydrated || !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function AppShell({ children }) {
	const user = useShop((s) => s.user);
	const logout = useShop((s) => s.logout);
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	if (!user) return null;
	const isCustomer = user.role === "customer";
	const nav = isCustomer ? [
		{
			to: "/",
			icon: LayoutDashboard,
			label: "হোম"
		},
		{
			to: "/orders",
			icon: ClipboardList,
			label: "অর্ডার"
		},
		{
			to: "/my-dues",
			icon: Wallet,
			label: "বাকি"
		},
		{
			to: "/profile",
			icon: CircleUserRound,
			label: "প্রোফাইল"
		}
	] : [
		{
			to: "/",
			icon: LayoutDashboard,
			label: "হোম"
		},
		{
			to: "/sales",
			icon: ShoppingCart,
			label: "বিক্রি"
		},
		{
			to: "/stock",
			icon: Package,
			label: "স্টক"
		},
		{
			to: "/collections",
			icon: Wallet,
			label: "বাকি"
		},
		{
			to: "/more",
			icon: Settings,
			label: "আরও"
		}
	];
	const handleLogout = () => {
		logout();
		navigate({ to: "/login" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-mint-3/80 bg-linear-to-b from-card via-card to-mint backdrop-blur-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-md items-center justify-between px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: SHOP.logo,
							alt: "",
							className: "size-10 rounded-xl object-cover shadow-[0_4px_14px_rgba(4,121,90,0.28)]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-[15px] font-bold tracking-tight text-fg",
								children: SHOP.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-[11px] font-medium text-muted",
								children: isCustomer ? "ক্রেতা প্যানেল" : SHOP.tagline
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-7 items-center justify-center rounded-full border border-mint-3 bg-mint-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary shadow-[0_0_0_3px_rgba(4,121,90,0.15)]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "মেনু",
							onClick: () => setMenuOpen((v) => !v),
							className: "flex size-9 items-center justify-center rounded-full border border-line bg-card shadow-sm",
							children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
						})]
					})]
				}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-md px-4 pb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-line bg-card p-2 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 border-b border-line px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: user.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted",
								children: [
									roleLabel(user.role),
									" • ",
									user.phone
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleLogout,
							className: "flex w-full items-center gap-2 rounded-sm px-3 py-2.5 text-sm font-medium text-danger",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 16 }), " লগআউট"]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-md pb-24",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card/95 pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_24px_rgba(0,0,0,0.04)] backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-[68px] max-w-md items-center justify-around px-1",
					children: nav.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("mx-0.5 flex h-full flex-1 flex-col items-center justify-center gap-1 rounded-md transition-colors", active ? "text-primary" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("flex size-7 items-center justify-center rounded-[10px]", active && "bg-mint-2"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									size: 20,
									strokeWidth: active ? 2.4 : 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("text-[10px] leading-none", active ? "font-semibold" : "font-medium"),
								children: item.label
							})]
						}, item.to);
					})
				})
			})
		]
	});
}
function PageTitle({ title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line bg-card px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold text-fg",
			children: title
		}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: subtitle
		}) : null]
	});
}
//#endregion
export { PageTitle as n, RequireAuth as r, AppShell as t };
