import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, g as useShop, h as todayKey, l as money, o as canManage, p as stockOf } from "./store-BntNszej.mjs";
import { p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stock-D-Mj4NFo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StockPage() {
	const products = useShop((s) => s.products);
	const sales = useShop((s) => s.sales);
	const purchases = useShop((s) => s.purchases);
	const adjustments = useShop((s) => s.adjustments);
	const addProduct = useShop((s) => s.addProduct);
	const addAdjustment = useShop((s) => s.addAdjustment);
	const user = useShop((s) => s.user);
	const manage = canManage(user?.role);
	const [q, setQ] = (0, import_react.useState)("");
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [adjId, setAdjId] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		return products.map((p) => {
			const qty = stockOf(p, sales, purchases, adjustments);
			return {
				p,
				qty,
				value: qty * p.purchasePrice,
				low: qty <= p.minStock
			};
		}).filter((r) => !q.trim() || r.p.name.includes(q) || r.p.code.toLowerCase().includes(q.toLowerCase())).sort((a, b) => Number(b.low) - Number(a.low));
	}, [
		products,
		sales,
		purchases,
		adjustments,
		q
	]);
	const low = rows.filter((r) => r.low).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "স্টক",
			subtitle: low ? `${bnNum(low)}টি পণ্যের স্টক কম` : "সব পণ্য পর্যাপ্ত"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 px-4 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "পণ্য খুঁজুন",
				className: "flex-1 rounded-md border border-line px-3 py-2.5 text-sm"
			}), manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setAddOpen(true),
				className: "rounded-md bg-primary px-3 text-card",
				"aria-label": "পণ্য যোগ",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 })
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2",
			children: rows.map(({ p, qty, value, low: isLow }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 border-b border-line px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted",
							children: [
								p.company,
								" • ",
								p.code,
								" • ",
								money(p.salePrice),
								"/",
								p.unit
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `text-sm font-bold tabular ${isLow ? "text-danger" : "text-primary"}`,
							children: [
								bnNum(qty),
								" ",
								p.unit
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted tabular",
							children: money(value)
						})]
					}),
					manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAdjId(p.id),
						className: "text-[11px] font-semibold text-primary",
						children: "সমন্বয়"
					}) : null
				]
			}, p.id))
		}),
		addOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductForm, {
			onClose: () => setAddOpen(false),
			onSave: (data) => {
				addProduct(data);
				setAddOpen(false);
				toast.success("পণ্য যোগ হয়েছে");
			}
		}) : null,
		adjId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdjustForm, {
			productId: adjId,
			onClose: () => setAdjId(null),
			onSave: (qty, reason) => {
				const p = products.find((x) => x.id === adjId);
				if (!p) return;
				addAdjustment({
					date: todayKey(),
					productId: p.id,
					productName: p.name,
					quantity: qty,
					reason
				});
				setAdjId(null);
				toast.success("স্টক সমন্বয় হয়েছে");
			}
		}) : null
	] });
}
function ProductForm({ onClose, onSave }) {
	const [name, setName] = (0, import_react.useState)("");
	const [company, setCompany] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("বস্তা");
	const [buy, setBuy] = (0, import_react.useState)(0);
	const [sell, setSell] = (0, import_react.useState)(0);
	const [open, setOpen] = (0, import_react.useState)(0);
	const [min, setMin] = (0, import_react.useState)(5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "নতুন পণ্য",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "নাম",
					value: name,
					onChange: setName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "কোম্পানি",
						value: company,
						onChange: setCompany
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "কোড",
						value: code,
						onChange: setCode
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs font-semibold",
					children: ["একক", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: unit,
						onChange: (e) => setUnit(e.target.value),
						className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "বস্তা" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "কেজি" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "পিস" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							label: "ক্রয় মূল্য",
							value: buy,
							onChange: setBuy
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							label: "বিক্রয় মূল্য",
							value: sell,
							onChange: setSell
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							label: "ওপেনিং স্টক",
							value: open,
							onChange: setOpen
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
							label: "মিন স্টক",
							value: min,
							onChange: setMin
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						if (!name.trim()) return toast.error("পণ্যের নাম দিন");
						onSave({
							code: code || name.slice(0, 3).toUpperCase(),
							name: name.trim(),
							company: company.trim() || "লোকাল",
							unit,
							purchasePrice: buy,
							salePrice: sell,
							openingStock: open,
							minStock: min
						});
					},
					className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
					children: "সংরক্ষণ"
				})
			]
		})
	});
}
function AdjustForm({ productId, onClose, onSave }) {
	const p = useShop((s) => s.products.find((x) => x.id === productId));
	const [qty, setQty] = (0, import_react.useState)(0);
	const [reason, setReason] = (0, import_react.useState)("গণনা সংশোধন");
	if (!p) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: `${p.name} সমন্বয়`,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs text-muted",
				children: "ধনাত্মক = স্টক বাড়বে, ঋণাত্মক = কমবে"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
				label: "পরিমাণ",
				value: qty,
				onChange: setQty
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 block text-xs font-semibold",
				children: ["কারণ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: reason,
					onChange: (e) => setReason(e.target.value),
					className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "গণনা সংশোধন" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ক্ষয়" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "নষ্ট" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "অন্যান্য" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (!qty) return toast.error("পরিমাণ দিন");
					onSave(qty, reason);
				},
				className: "mt-4 w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
				children: "সমন্বয় করুন"
			})
		]
	});
}
function Modal({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-fg/50 p-3 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl bg-card p-4",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "বন্ধ",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
				})]
			}), children]
		})
	});
}
function Field({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs font-semibold",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
		})]
	});
}
function Num({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs font-semibold",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "number",
			value: value || "",
			onChange: (e) => onChange(Number(e.target.value) || 0),
			className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockPage, {}) }) });
//#endregion
export { SplitComponent as component };
