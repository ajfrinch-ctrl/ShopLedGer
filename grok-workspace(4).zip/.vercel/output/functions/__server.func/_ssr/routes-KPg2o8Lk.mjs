import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, d as profitSummary, g as useShop, h as todayKey, i as bnDate, l as money, m as supplierDue, o as canManage, p as stockOf, r as allCustomerDues, s as canSeeProfit, u as monthStartKey } from "./store-BntNszej.mjs";
import { A as CalendarDays, F as ArrowDownLeft, N as ArrowUpRight, O as ChartColumn, P as ArrowRight, a as TrendingUp, c as ShoppingBag, f as Receipt, h as Package, n as Wallet, p as Plus, s as ShoppingCart, x as History } from "../_libs/lucide-react.mjs";
import { r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-KPg2o8Lk.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	if (useShop((s) => s.user)?.role === "customer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomerHome, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopHome, {});
}
function ShopHome() {
	const user = useShop((s) => s.user);
	const sales = useShop((s) => s.sales);
	const purchases = useShop((s) => s.purchases);
	const expenses = useShop((s) => s.expenses);
	const collections = useShop((s) => s.collections);
	const products = useShop((s) => s.products);
	const customers = useShop((s) => s.customers);
	const adjustments = useShop((s) => s.adjustments);
	const showProfit = canSeeProfit(user?.role);
	const showBuy = canManage(user?.role);
	const today = todayKey();
	const month = monthStartKey(today);
	const daily = profitSummary(sales, expenses, today, today);
	const monthly = profitSummary(sales, expenses, month, today);
	const todayCollected = collections.filter((c) => c.kind === "customer" && c.date === today).reduce((a, c) => a + c.amount, 0);
	const totalDues = allCustomerDues(customers, sales, collections).reduce((a, d) => a + d.due, 0);
	const supplierDues = [...new Set(purchases.map((p) => p.supplier))].reduce((a, name) => a + Math.max(0, supplierDue(name, purchases, collections)), 0);
	const stockValue = products.reduce((a, p) => a + stockOf(p, sales, purchases, adjustments) * p.purchasePrice, 0);
	const lowStock = products.filter((p) => stockOf(p, sales, purchases, adjustments) <= p.minStock).length;
	const todayBangla = (/* @__PURE__ */ new Date()).toLocaleDateString("bn-BD", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	const recent = [
		...sales.map((s) => ({
			key: s.id,
			type: "বিক্রি",
			party: s.customerName,
			amount: s.total,
			date: s.date,
			to: "/sales"
		})),
		...collections.map((c) => ({
			key: c.id,
			type: c.kind === "customer" ? "আদায়" : "পরিশোধ",
			party: c.partyName,
			amount: c.amount,
			date: c.date,
			to: "/collections"
		})),
		...expenses.map((e) => ({
			key: e.id,
			type: "খরচ",
			party: e.category,
			amount: e.amount,
			date: e.date,
			to: "/expenses"
		})),
		...purchases.map((p) => ({
			key: p.id,
			type: "ক্রয়",
			party: p.supplier,
			amount: p.total,
			date: p.date,
			to: "/purchases"
		}))
	].sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl border border-line bg-card shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pt-5 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-7 items-center justify-center rounded-xs bg-mint-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, {
									size: 14,
									className: "text-primary"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-bold",
								children: "আজকের হিসাব"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-line bg-bg px-2.5 py-1 text-[11px] font-medium text-muted",
							children: todayBangla
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "বিক্রি",
								value: money(daily.revenue),
								sub: `${bnNum(daily.saleCount)}টি`,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { size: 18 }),
								tone: "bg-[#fff7ed]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "আদায়",
								value: money(todayCollected),
								sub: "বাকি আদায়",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { size: 18 }),
								tone: "bg-mint"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: showBuy ? "খরচ" : "বাকি",
								value: money(showBuy ? daily.shopExp : totalDues),
								sub: showBuy ? "দোকান খরচ" : "পাওনা",
								icon: showBuy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownLeft, { size: 18 }),
								tone: "bg-[#eff6ff]"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-t border-mint-3 bg-mint px-5 py-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-8 items-center justify-center rounded-[10px] border border-mint-3 bg-card",
							children: showProfit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, {
								size: 16,
								className: "text-primary"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, {
								size: 16,
								className: "text-primary"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium text-primary-dark",
							children: showProfit ? "আজকের নিট লাভ" : "মোট স্টক মূল্য"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: showProfit ? "খরচ বাদে" : lowStock ? `${bnNum(lowStock)}টি কম` : "সব ঠিক আছে"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-[15px] font-bold tabular ${showProfit && daily.net < 0 ? "text-danger" : "text-primary"}`,
						children: showProfit ? money(daily.net) : money(stockValue)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[13px] font-bold",
					children: "দ্রুত কাজ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-line bg-card px-2.5 py-1 text-[11px] text-muted",
					children: "৪টি অপশন"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-line bg-card p-4 shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/sales",
							label: "নতুন বিক্রি",
							className: "bg-primary",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								size: 22,
								strokeWidth: 2.5
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/collections",
							label: "বাকি আদায়",
							className: "bg-sale",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { size: 20 })
						}),
						showBuy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/purchases",
							label: "ক্রয়",
							className: "bg-info",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { size: 20 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/expenses",
							label: "খরচ",
							className: "bg-warn",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { size: 20 })
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/stock",
							label: "স্টক",
							className: "bg-info",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { size: 20 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/customers",
							label: "ক্রেতা",
							className: "bg-warn",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { size: 20 })
						})] })
					]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "mb-3 flex items-center gap-2 px-1 text-[13px] font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { size: 12 }), " বর্তমান হিসাব"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {
						to: "/collections",
						label: "আমরা পাব",
						detail: "ক্রেতার বাকি",
						value: totalDues,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownLeft, { size: 18 })
					}),
					showBuy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {
						to: "/purchases",
						label: "আমরা দেব",
						detail: "সাপ্লায়ার পাওনা",
						value: supplierDues,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 18 })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {
						to: "/stock",
						label: "মোট স্টক মূল্য",
						detail: lowStock ? `${bnNum(lowStock)}টি পণ্যের স্টক কম` : "সব পণ্য পর্যাপ্ত",
						value: stockValue,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { size: 18 })
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "mb-3 flex items-center gap-2 px-1 text-[13px] font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { size: 12 }), " চলতি মাস"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3 rounded-xl border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "বিক্রি",
						value: monthly.revenue
					}),
					showBuy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "খরচ",
						value: monthly.shopExp
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "লাভ",
						value: monthly.net
					}),
					showProfit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "লাভ",
						value: monthly.net,
						highlight: true
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "স্টক",
						value: stockValue
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "flex items-center gap-2 text-[13px] font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { size: 12 }), " সাম্প্রতিক"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/reports",
						className: "inline-flex items-center gap-1 rounded-full bg-mint-2 px-3 py-1 text-[11px] font-semibold text-primary",
						children: ["সব দেখুন ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 12 })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-xl border border-line bg-card",
					children: recent.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line",
						children: recent.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: r.to,
							className: "flex items-center gap-3 px-4 py-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex size-10 items-center justify-center rounded-sm bg-mint text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { size: 16 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-muted",
										children: [
											bnDate(r.date),
											" • ",
											r.type
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[13px] font-medium",
										children: r.party
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[13px] font-bold tabular",
									children: money(r.amount)
								})
							]
						}) }, r.key))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-8 text-center text-sm text-muted",
						children: "এখনও কোনো লেনদেন নেই"
					})
				})]
			})
		]
	});
}
function CustomerHome() {
	const user = useShop((s) => s.user);
	const sales = useShop((s) => s.sales);
	const orders = useShop((s) => s.orders);
	const due = useShop((s) => user?.customerId ? s.dueOf(user.customerId) : 0);
	const mine = sales.filter((s) => s.customerId === user?.customerId);
	const pending = orders.filter((o) => o.customerId === user?.customerId && o.status === "pending").length;
	const spent = mine.reduce((a, s) => a + s.total, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-primary p-5 text-card shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mint-2",
						children: "আসসালামু আলাইকুম"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-bold",
						children: user?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-[11px] text-mint-2",
						children: "বর্তমান বাকি"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-bold tabular",
						children: money(due)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-line bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: "মোট কেনাকাটা"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-lg font-bold tabular",
						children: money(spent)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-line bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted",
						children: "অপেক্ষমাণ অর্ডার"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-lg font-bold tabular",
						children: bnNum(pending)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/orders",
					className: "rounded-lg bg-primary py-3 text-center text-sm font-semibold text-card",
					children: "নতুন অর্ডার"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/my-dues",
					className: "rounded-lg border border-line bg-card py-3 text-center text-sm font-semibold",
					children: "হিসাব দেখুন"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "border-b border-line px-4 py-3 text-sm font-semibold",
						children: "সাম্প্রতিক বিল"
					}),
					mine.slice(0, 5).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-line px-4 py-3 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: s.billNo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: bnDate(s.date)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold tabular",
							children: money(s.total)
						})]
					}, s.id)),
					!mine.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted",
						children: "এখনও কোনো বিল নেই"
					}) : null
				]
			})
		]
	});
}
function Stat({ label, value, sub, icon, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex flex-col items-center rounded-md p-3 text-center ${tone}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 flex size-11 items-center justify-center rounded-sm bg-primary text-card",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[13px] font-bold leading-tight tabular",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[10px] text-muted",
				children: sub
			})
		]
	});
}
function Quick({ to, label, icon, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `flex size-[52px] items-center justify-center rounded-md text-card shadow-md ${className}`,
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-center text-[11px] font-medium leading-tight",
			children: label
		})]
	});
}
function Account({ to, label, detail, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex items-center gap-3 px-4 py-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-10 items-center justify-center rounded-sm bg-mint text-primary",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted",
					children: detail
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-bold tabular",
				children: money(value)
			})
		]
	});
}
function Chip({ label, value, highlight }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[11px] text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `mt-1 text-sm font-bold tabular ${highlight ? "text-primary" : ""} ${value < 0 ? "text-danger" : ""}`,
		children: money(value)
	})] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home, {}) }) });
//#endregion
export { SplitComponent as component };
