import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as customerDue, g as useShop, i as bnDate, l as money, n as SHOP } from "./store-BntNszej.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/my-dues-fXj82tdg.js
var import_jsx_runtime = require_jsx_runtime();
function MyDuesPage() {
	const user = useShop((s) => s.user);
	const sales = useShop((s) => s.sales);
	const collections = useShop((s) => s.collections);
	const id = user?.customerId;
	const due = id ? customerDue(id, sales, collections) : 0;
	const mine = sales.filter((s) => s.customerId === id);
	const cols = collections.filter((c) => c.kind === "customer" && c.partyId === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "আমার বাকি",
			subtitle: "দোকানের খাতা অনুযায়ী"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "m-4 rounded-xl bg-primary p-5 text-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-mint-2",
					children: "বর্তমান বাকি"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-3xl font-bold tabular",
					children: money(due)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-[11px] text-mint-2",
					children: ["জমা দিতে দোকানে আসুন • ", SHOP.phones[0]]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "px-4 text-sm font-bold",
			children: "বিল"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: mine.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: s.billNo
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted",
				children: bnDate(s.date)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-bold tabular",
				children: money(s.total)
			})]
		}, s.id)) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-4 px-4 text-sm font-bold",
			children: "জমা"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: bnDate(c.date)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-bold tabular text-primary",
				children: money(c.amount)
			})]
		}, c.id)), !cols.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-4 text-sm text-muted",
			children: "এখনও কোনো জমা নেই"
		}) : null] })
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyDuesPage, {}) }) });
//#endregion
export { SplitComponent as component };
