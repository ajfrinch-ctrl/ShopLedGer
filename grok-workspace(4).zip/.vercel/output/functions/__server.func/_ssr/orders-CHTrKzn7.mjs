import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, g as useShop, i as bnDate, l as money } from "./store-BntNszej.mjs";
import { g as Minus, p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as ReceiptModal } from "./receipt-modal-D3JWBUQv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-CHTrKzn7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	pending: "অপেক্ষমাণ",
	accepted: "গ্রহণ",
	delivered: "ডেলিভারি",
	cancelled: "বাতিল"
};
function OrdersPage() {
	const user = useShop((s) => s.user);
	const isCustomer = user?.role === "customer";
	const orders = useShop((s) => s.orders);
	const products = useShop((s) => s.products);
	const addOrder = useShop((s) => s.addOrder);
	const setOrderStatus = useShop((s) => s.setOrderStatus);
	const fulfillOrder = useShop((s) => s.fulfillOrder);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [cart, setCart] = (0, import_react.useState)([]);
	const [note, setNote] = (0, import_react.useState)("");
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const visible = isCustomer ? orders.filter((o) => o.customerId === user?.customerId) : orders;
	const add = (p) => {
		setCart((c) => {
			if (c.find((i) => i.productId === p.id)) return c.map((i) => i.productId === p.id ? {
				...i,
				quantity: i.quantity + 1,
				total: (i.quantity + 1) * i.salePrice
			} : i);
			return [...c, {
				productId: p.id,
				productName: p.name,
				unit: p.unit,
				quantity: 1,
				salePrice: p.salePrice,
				total: p.salePrice
			}];
		});
	};
	const total = (0, import_react.useMemo)(() => cart.reduce((a, i) => a + i.total, 0), [cart]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "অর্ডার",
			subtitle: isCustomer ? "দোকানে অর্ডার পাঠান" : "ক্রেতার অর্ডার গ্রহণ করুন"
		}),
		isCustomer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
				children: "নতুন অর্ডার"
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-3",
			children: [visible.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-b border-line px-4 py-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: o.customerName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted",
							children: [
								bnDate(o.createdAt.slice(0, 10)),
								" • ",
								bnNum(o.items.length),
								"টি পণ্য"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: o.items.map((i) => `${i.productName} × ${bnNum(i.quantity)}`).join(", ")
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold tabular",
							children: money(o.total)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-primary",
							children: STATUS[o.status]
						})]
					})]
				}), !isCustomer && o.status !== "delivered" && o.status !== "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [
						o.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOrderStatus(o.id, "accepted"),
							className: "rounded-full bg-mint-2 px-3 py-1 text-xs font-semibold text-primary",
							children: "গ্রহণ"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								const sale = fulfillOrder(o.id);
								if (sale) {
									toast.success("বিক্রি হয়েছে, বাকিতে যোগ");
									setReceipt(sale);
								}
							},
							className: "rounded-full bg-primary px-3 py-1 text-xs font-semibold text-card",
							children: "ডেলিভারি → বিক্রি"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOrderStatus(o.id, "cancelled"),
							className: "rounded-full bg-bg px-3 py-1 text-xs font-semibold text-danger",
							children: "বাতিল"
						})
					]
				}) : null]
			}, o.id)), !visible.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-sm text-muted",
				children: "কোনো অর্ডার নেই"
			}) : null]
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 flex items-end bg-fg/50 sm:items-center sm:justify-center",
			onClick: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex max-h-[92dvh] w-full max-w-md flex-col overflow-hidden rounded-t-xl bg-card sm:rounded-xl",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold",
							children: "নতুন অর্ডার"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "বন্ধ",
							onClick: () => setOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 overflow-y-auto p-4",
						children: [
							products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => add(p),
								className: "flex w-full items-center justify-between border-b border-line py-2.5 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold tabular",
									children: money(p.salePrice)
								})]
							}, p.id)),
							cart.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-2",
								children: cart.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between rounded-md bg-mint px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm",
										children: i.productName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCart((c) => c.map((x) => x.productId === i.productId ? {
													...x,
													quantity: x.quantity - 1,
													total: (x.quantity - 1) * x.salePrice
												} : x).filter((x) => x.quantity > 0)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 14 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-6 text-center text-sm font-bold tabular",
												children: bnNum(i.quantity)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => add(products.find((p) => p.id === i.productId)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 })
											})
										]
									})]
								}, i.productId))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: note,
								onChange: (e) => setNote(e.target.value),
								placeholder: "নোট",
								className: "mt-3 w-full rounded-md border border-line px-3 py-2 text-sm",
								rows: 2
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-2 flex justify-between text-sm font-bold",
							children: ["মোট ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular",
								children: money(total)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (!cart.length || !user?.customerId) return toast.error("পণ্য যোগ করুন");
								addOrder({
									customerId: user.customerId,
									customerName: user.name,
									items: cart,
									total,
									note: note.trim() || void 0
								});
								setOpen(false);
								setCart([]);
								setNote("");
								toast.success("অর্ডার পাঠানো হয়েছে");
							},
							className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
							children: "অর্ডার পাঠান"
						})]
					})
				]
			})
		}) : null,
		receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptModal, {
			sale: receipt,
			onClose: () => setReceipt(null)
		}) : null
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersPage, {}) }) });
//#endregion
export { SplitComponent as component };
