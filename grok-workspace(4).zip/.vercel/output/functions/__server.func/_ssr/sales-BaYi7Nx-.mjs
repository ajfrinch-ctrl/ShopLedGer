import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, V as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, g as useShop, h as todayKey, i as bnDate, l as money, p as stockOf } from "./store-BntNszej.mjs";
import { d as Search, g as Minus, o as Trash2, p as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageTitle, r as RequireAuth, t as AppShell } from "./app-shell-Cn2xiPK-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as ReceiptModal } from "./receipt-modal-D3JWBUQv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sales-BaYi7Nx-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SalesPage() {
	const sales = useShop((s) => s.sales);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			title: "বিক্রি",
			subtitle: "নতুন বিল কাটুন, রসিদ দেখুন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(true),
				className: "flex w-full items-center justify-center gap-2 rounded-md bg-primary py-3.5 text-sm font-bold text-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " নতুন বিক্রি"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-line",
			children: sales.map((s) => {
				const due = s.total - s.paid;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setReceipt(s),
					className: "flex w-full items-center gap-3 px-4 py-3.5 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: s.customerName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted",
							children: [
								s.billNo,
								" • ",
								bnDate(s.date),
								" • ",
								bnNum(s.items.length),
								"টি পণ্য"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold tabular",
							children: money(s.total)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-[11px] ${due > 0 ? "text-danger" : "text-primary"}`,
							children: due > 0 ? `বাকি ${money(due)}` : "পরিশোধিত"
						})]
					})]
				}) }, s.id);
			})
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaleComposer, {
			onClose: () => setOpen(false),
			onSaved: (s) => {
				setOpen(false);
				setReceipt(s);
			}
		}) : null,
		receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptModal, {
			sale: receipt,
			onClose: () => setReceipt(null)
		}) : null
	] });
}
function SaleComposer({ onClose, onSaved }) {
	const products = useShop((s) => s.products);
	const customers = useShop((s) => s.customers);
	const sales = useShop((s) => s.sales);
	const purchases = useShop((s) => s.purchases);
	const adjustments = useShop((s) => s.adjustments);
	const addSale = useShop((s) => s.addSale);
	const addCustomer = useShop((s) => s.addCustomer);
	const [date, setDate] = (0, import_react.useState)(todayKey());
	const [q, setQ] = (0, import_react.useState)("");
	const [custId, setCustId] = (0, import_react.useState)("");
	const [newCust, setNewCust] = (0, import_react.useState)(false);
	const [custName, setCustName] = (0, import_react.useState)("");
	const [custPhone, setCustPhone] = (0, import_react.useState)("");
	const [cart, setCart] = (0, import_react.useState)([]);
	const [discount, setDiscount] = (0, import_react.useState)(0);
	const [paid, setPaid] = (0, import_react.useState)(0);
	const filtered = (0, import_react.useMemo)(() => {
		const n = q.trim();
		return products.filter((p) => !n || p.name.includes(n) || p.code.toLowerCase().includes(n.toLowerCase()) || p.company.includes(n));
	}, [products, q]);
	const subtotal = cart.reduce((a, i) => a + i.total, 0);
	const total = Math.max(0, subtotal - discount);
	const due = Math.max(0, total - paid);
	const addProduct = (p) => {
		const stock = stockOf(p, sales, purchases, adjustments);
		const existing = cart.find((i) => i.productId === p.id);
		const nextQty = (existing?.quantity ?? 0) + 1;
		if (nextQty > stock) {
			toast.error(`${p.name} — স্টক ${bnNum(stock)} ${p.unit}`);
			return;
		}
		if (existing) setCart((c) => c.map((i) => i.productId === p.id ? {
			...i,
			quantity: nextQty,
			total: nextQty * i.salePrice
		} : i));
		else setCart((c) => [...c, {
			productId: p.id,
			productName: p.name,
			unit: p.unit,
			quantity: 1,
			salePrice: p.salePrice,
			purchasePrice: p.purchasePrice,
			total: p.salePrice
		}]);
	};
	const setQty = (id, qty) => {
		if (qty <= 0) {
			setCart((c) => c.filter((i) => i.productId !== id));
			return;
		}
		const p = products.find((x) => x.id === id);
		if (p) {
			const stock = stockOf(p, sales, purchases, adjustments);
			if (qty > stock) {
				toast.error(`স্টক মাত্র ${bnNum(stock)}`);
				return;
			}
		}
		setCart((c) => c.map((i) => i.productId === id ? {
			...i,
			quantity: qty,
			total: qty * i.salePrice
		} : i));
	};
	const save = () => {
		if (!cart.length) {
			toast.error("অন্তত একটি পণ্য যোগ করুন");
			return;
		}
		let customerId = custId || void 0;
		let customerName = "নগদ ক্রেতা";
		if (newCust) {
			if (!custName.trim()) {
				toast.error("ক্রেতার নাম দিন");
				return;
			}
			const c = addCustomer({
				name: custName.trim(),
				phone: custPhone.trim(),
				address: ""
			});
			customerId = c.id;
			customerName = c.name;
		} else if (custId) customerName = customers.find((c) => c.id === custId)?.name ?? "ক্রেতা";
		if (due > 0 && !customerId) {
			toast.error("বাকি রাখতে ক্রেতা নির্বাচন করুন");
			return;
		}
		const sale = addSale({
			date,
			items: cart,
			discount,
			paid,
			customerId,
			customerName
		});
		toast.success(`${sale.billNo} সংরক্ষণ হয়েছে`);
		onSaved(sale);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-fg/50 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[94dvh] w-full max-w-md flex-col overflow-hidden rounded-t-xl bg-card sm:rounded-xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "নতুন বিক্রি"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-4 overflow-y-auto p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-semibold",
							children: ["তারিখ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								max: todayKey(),
								value: date,
								onChange: (e) => setDate(e.target.value),
								className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setNewCust(false);
									setCustId("");
								},
								className: `rounded-full px-3 py-1.5 text-xs font-medium ${!custId && !newCust ? "bg-primary text-card" : "bg-mint-2"}`,
								children: "নগদ ক্রেতা"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setNewCust(true),
								className: `rounded-full px-3 py-1.5 text-xs font-medium ${newCust ? "bg-primary text-card" : "bg-mint-2"}`,
								children: "নতুন ক্রেতা"
							})]
						}), newCust ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: custName,
								onChange: (e) => setCustName(e.target.value),
								placeholder: "নাম",
								className: "rounded-md border border-line px-3 py-2.5 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: custPhone,
								onChange: (e) => setCustPhone(e.target.value),
								placeholder: "মোবাইল",
								className: "rounded-md border border-line px-3 py-2.5 text-sm"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: custId,
							onChange: (e) => {
								setCustId(e.target.value);
								setNewCust(false);
							},
							className: "w-full rounded-md border border-line px-3 py-2.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "নগদ ক্রেতা / খাতা বাছুন"
							}), customers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: c.id,
								children: [
									c.name,
									" — ",
									c.phone
								]
							}, c.id))]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								size: 16,
								className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "পণ্য খুঁজুন",
								className: "w-full rounded-md border border-line py-2.5 pl-9 pr-3 text-sm"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 max-h-40 overflow-y-auto rounded-md border border-line",
							children: filtered.slice(0, 8).map((p) => {
								const st = stockOf(p, sales, purchases, adjustments);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => addProduct(p),
									className: "flex w-full items-center justify-between border-b border-line px-3 py-2 text-left last:border-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-muted",
										children: [
											"স্টক ",
											bnNum(st),
											" ",
											p.unit
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold tabular",
										children: money(p.salePrice)
									})]
								}, p.id);
							})
						})] }),
						cart.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: cart.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2 rounded-md bg-mint px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: i.productName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted tabular",
											children: money(i.salePrice)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "rounded-full bg-card p-1",
												onClick: () => setQty(i.productId, i.quantity - 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 14 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-7 text-center text-sm font-bold tabular",
												children: bnNum(i.quantity)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "rounded-full bg-card p-1",
												onClick: () => setQty(i.productId, i.quantity + 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 })
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setQty(i.productId, 0),
										className: "text-danger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
									})
								]
							}, i.productId))
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-semibold",
								children: ["ছাড় (৳)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									value: discount || "",
									onChange: (e) => setDiscount(Number(e.target.value) || 0),
									className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-semibold",
								children: ["জমা (৳)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									value: paid || "",
									onChange: (e) => setPaid(Number(e.target.value) || 0),
									className: "mt-1 w-full rounded-md border border-line px-3 py-2.5 text-sm"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPaid(total),
								className: "flex-1 rounded-full bg-mint-2 py-2 text-xs font-semibold text-primary",
								children: "পুরোটা নগদ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPaid(0),
								className: "flex-1 rounded-full bg-mint-2 py-2 text-xs font-semibold",
								children: "পুরোটা বাকি"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-line p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "মোট" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold tabular",
								children: money(total)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "বাকি থাকবে" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `font-bold tabular ${due ? "text-danger" : "text-primary"}`,
								children: money(due)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: save,
							className: "w-full rounded-md bg-primary py-3 text-sm font-bold text-card",
							children: "বিল সংরক্ষণ"
						})
					]
				})
			]
		})
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesPage, {}) }) });
//#endregion
export { SplitComponent as component };
