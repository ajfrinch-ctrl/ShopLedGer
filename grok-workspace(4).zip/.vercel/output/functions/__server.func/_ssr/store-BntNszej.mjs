import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-BntNszej.js
var SHOP = {
	name: "কর্ণফুলী সেলস সেন্টার",
	tagline: "গবাদি পশুর খাদ্য সরবরাহ",
	branch: "প্রধান শাখা",
	address: "পল্লি বিদ্যুৎ অফিসের পাশে, বুড়া মসজিদ রোড, আমুচিয়া, বোয়ালখালী, চট্টগ্রাম",
	phones: ["01821989717", "01811808294"],
	logo: "/brand/karnaphuli-mark.jpg"
};
var DEMO_ACCOUNTS = [
	{
		id: "u-owner-1",
		name: "মো. জসিম উদ্দিন",
		phone: "01821989717",
		password: "123456",
		role: "owner"
	},
	{
		id: "u-owner-2",
		name: "মো. ফরিদুল ইসলাম",
		phone: "01811808294",
		password: "123456",
		role: "owner"
	},
	{
		id: "u-sales-1",
		name: "রহিম উদ্দিন",
		phone: "01800000000",
		password: "123456",
		role: "salesman"
	},
	{
		id: "u-cust-1",
		name: "করিম মিয়া",
		phone: "01900000000",
		password: "123456",
		role: "customer",
		customerId: "c-1"
	}
];
function stockOf(product, sales, purchases, adjustments) {
	const sold = sales.reduce((sum, s) => sum + s.items.filter((i) => i.productId === product.id).reduce((a, i) => a + i.quantity, 0), 0);
	const bought = purchases.filter((p) => p.productId === product.id).reduce((a, p) => a + p.quantity, 0);
	const adj = adjustments.filter((a) => a.productId === product.id).reduce((a, x) => a + x.quantity, 0);
	return product.openingStock + bought + adj - sold;
}
function customerDue(customerId, sales, collections) {
	return sales.filter((s) => s.customerId === customerId).reduce((a, s) => a + (s.total - s.paid), 0) - collections.filter((c) => c.kind === "customer" && c.partyId === customerId).reduce((a, c) => a + c.amount, 0);
}
function supplierDue(supplier, purchases, collections) {
	return purchases.filter((p) => p.supplier === supplier).reduce((a, p) => a + (p.total - p.paid), 0) - collections.filter((c) => c.kind === "supplier" && c.partyName === supplier).reduce((a, c) => a + c.amount, 0);
}
function allCustomerDues(customers, sales, collections) {
	return customers.map((c) => ({
		customer: c,
		due: customerDue(c.id, sales, collections)
	})).filter((x) => x.due > .5).sort((a, b) => b.due - a.due);
}
function inRange(date, from, to) {
	return date >= from && date <= to;
}
function profitSummary(sales, expenses, from, to) {
	const rows = sales.filter((s) => inRange(s.date, from, to));
	const revenue = rows.reduce((a, s) => a + s.total, 0);
	const cogs = rows.reduce((a, s) => a + s.items.reduce((x, i) => x + i.purchasePrice * i.quantity, 0), 0);
	const shopExp = expenses.filter((e) => e.kind === "shop" && inRange(e.date, from, to)).reduce((a, e) => a + e.amount, 0);
	const ownerDraw = expenses.filter((e) => e.kind === "owner" && inRange(e.date, from, to)).reduce((a, e) => a + e.amount, 0);
	const gross = revenue - cogs;
	const net = gross - shopExp;
	return {
		saleCount: rows.length,
		revenue,
		cogs,
		gross,
		shopExp,
		ownerDraw,
		net
	};
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return d.toLocaleDateString("en-CA", { timeZone: "Asia/Dhaka" });
}
function shiftKey(days) {
	const now = /* @__PURE__ */ new Date();
	now.setDate(now.getDate() + days);
	return todayKey(now);
}
function money(n) {
	const rounded = Math.round(n);
	const formatted = Math.abs(rounded).toLocaleString("bn-BD");
	return rounded < 0 ? `−৳${formatted}` : `৳${formatted}`;
}
function bnNum(n) {
	return Math.round(n).toLocaleString("bn-BD");
}
function bnDate(key) {
	return (/* @__PURE__ */ new Date(`${key}T12:00:00`)).toLocaleDateString("bn-BD", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
function nid(prefix) {
	return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}
function monthStartKey(key = todayKey()) {
	return `${key.slice(0, 7)}-01`;
}
function createSeed() {
	const today = todayKey();
	const d1 = shiftKey(-1);
	const d2 = shiftKey(-2);
	const d5 = shiftKey(-5);
	const d8 = shiftKey(-8);
	const d12 = shiftKey(-12);
	const products = [
		{
			id: "p-1",
			code: "NDN-001",
			name: "নন্দন ফ্যাটনিং পেলেট ৫০ কেজি",
			company: "নন্দন",
			unit: "বস্তা",
			purchasePrice: 2450,
			salePrice: 2750,
			openingStock: 48,
			minStock: 8,
			createdAt: d12
		},
		{
			id: "p-2",
			code: "NDN-002",
			name: "নন্দন ডেইরি ফিড ৫০ কেজি",
			company: "নন্দন",
			unit: "বস্তা",
			purchasePrice: 2280,
			salePrice: 2580,
			openingStock: 36,
			minStock: 6,
			createdAt: d12
		},
		{
			id: "p-3",
			code: "QTY-101",
			name: "কোয়ালিটি ব্রয়লার স্টার্টার ৫০ কেজি",
			company: "Quality",
			unit: "বস্তা",
			purchasePrice: 2520,
			salePrice: 2850,
			openingStock: 22,
			minStock: 5,
			createdAt: d12
		},
		{
			id: "p-4",
			code: "QTY-102",
			name: "কোয়ালিটি লেয়ার ৫০ কেজি",
			company: "Quality",
			unit: "বস্তা",
			purchasePrice: 2380,
			salePrice: 2680,
			openingStock: 18,
			minStock: 5,
			createdAt: d12
		},
		{
			id: "p-5",
			code: "GT-201",
			name: "ছাগল মোটাতাজা ২৫ কেজি",
			company: "লোকাল",
			unit: "বস্তা",
			purchasePrice: 1180,
			salePrice: 1380,
			openingStock: 30,
			minStock: 6,
			createdAt: d12
		},
		{
			id: "p-6",
			code: "KH-301",
			name: "সরিষার খৈল ৪০ কেজি",
			company: "লোকাল",
			unit: "বস্তা",
			purchasePrice: 1520,
			salePrice: 1750,
			openingStock: 40,
			minStock: 10,
			createdAt: d12
		},
		{
			id: "p-7",
			code: "VH-302",
			name: "গমের ভুসি ৪০ কেজি",
			company: "লোকাল",
			unit: "বস্তা",
			purchasePrice: 980,
			salePrice: 1180,
			openingStock: 55,
			minStock: 12,
			createdAt: d12
		},
		{
			id: "p-8",
			code: "VH-303",
			name: "আটা ভুসি ৪০ কেজি",
			company: "লোকাল",
			unit: "বস্তা",
			purchasePrice: 920,
			salePrice: 1100,
			openingStock: 28,
			minStock: 8,
			createdAt: d12
		},
		{
			id: "p-9",
			code: "SL-401",
			name: "চাট লবণ ১ কেজি",
			company: "ACI",
			unit: "কেজি",
			purchasePrice: 42,
			salePrice: 65,
			openingStock: 80,
			minStock: 15,
			createdAt: d12
		},
		{
			id: "p-10",
			code: "VT-501",
			name: "ভিটামিন প্রিমিক্স ১ কেজি",
			company: "ACI",
			unit: "কেজি",
			purchasePrice: 320,
			salePrice: 450,
			openingStock: 12,
			minStock: 4,
			createdAt: d12
		}
	];
	const customers = [
		{
			id: "c-1",
			name: "করিম মিয়া",
			phone: "01900000000",
			address: "পদুয়া, বোয়ালখালী",
			createdAt: d12
		},
		{
			id: "c-2",
			name: "আবদুল মালেক",
			phone: "01815551234",
			address: "আমুচিয়া, বোয়ালখালী",
			createdAt: d12
		},
		{
			id: "c-3",
			name: "নুরুল ইসলাম",
			phone: "01816667890",
			address: "কাঞ্চনা, বোয়ালখালী",
			createdAt: d8
		},
		{
			id: "c-4",
			name: "ফাতেমা বেগম",
			phone: "01817774321",
			address: "শাকপুরা",
			createdAt: d8
		},
		{
			id: "c-5",
			name: "রফিক উদ্দিন",
			phone: "01818889012",
			address: "বুড়া মসজিদ রোড",
			createdAt: d5
		}
	];
	const item = (p, qty) => ({
		productId: p.id,
		productName: p.name,
		unit: p.unit,
		quantity: qty,
		salePrice: p.salePrice,
		purchasePrice: p.purchasePrice,
		total: p.salePrice * qty
	});
	function sale(id, bill, date, customer, lines, paidRatio, by = "মো. জসিম উদ্দিন") {
		const items = lines.map((l) => item(l.p, l.q));
		const subtotal = items.reduce((a, i) => a + i.total, 0);
		const total = subtotal;
		return {
			id,
			billNo: bill,
			date,
			items,
			subtotal,
			discount: 0,
			total,
			paid: Math.round(total * paidRatio),
			customerId: customer?.id,
			customerName: customer?.name ?? "নগদ ক্রেতা",
			createdBy: by,
			createdAt: `${date}T10:30:00`
		};
	}
	const [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10] = products;
	const [c1, c2, c3, c4, c5] = customers;
	return {
		products,
		customers,
		sales: [
			sale("s-1", "বিল-১০৪২", d12, c1, [{
				p: p1,
				q: 4
			}, {
				p: p6,
				q: 2
			}], .4),
			sale("s-2", "বিল-১০৪৩", d8, c2, [{
				p: p2,
				q: 3
			}, {
				p: p7,
				q: 5
			}], .5),
			sale("s-3", "বিল-১০৪৪", d5, c3, [{
				p: p3,
				q: 2
			}, {
				p: p9,
				q: 10
			}], 1),
			sale("s-4", "বিল-১০৪৫", d2, c4, [{
				p: p5,
				q: 4
			}, {
				p: p8,
				q: 2
			}], 0),
			sale("s-5", "বিল-১০৪৬", d1, c1, [{
				p: p1,
				q: 2
			}, {
				p: p10,
				q: 2
			}], .3),
			sale("s-6", "বিল-১০৪৭", today, c2, [{
				p: p2,
				q: 2
			}, {
				p: p6,
				q: 3
			}], .6),
			sale("s-7", "বিল-১০৪৮", today, null, [{
				p: p7,
				q: 4
			}, {
				p: p9,
				q: 6
			}], 1),
			sale("s-8", "বিল-১০৪৯", today, c5, [{
				p: p4,
				q: 1
			}, {
				p: p1,
				q: 1
			}], 0)
		],
		purchases: [
			{
				id: "pu-1",
				date: d8,
				productId: p1.id,
				productName: p1.name,
				quantity: 20,
				unit: p1.unit,
				purchasePrice: p1.purchasePrice,
				total: 20 * p1.purchasePrice,
				supplier: "নন্দন ফিড মিলস",
				paid: 20 * p1.purchasePrice,
				createdAt: d8
			},
			{
				id: "pu-2",
				date: d5,
				productId: p3.id,
				productName: p3.name,
				quantity: 12,
				unit: p3.unit,
				purchasePrice: p3.purchasePrice,
				total: 12 * p3.purchasePrice,
				supplier: "Quality Feeds Ltd",
				paid: 0,
				createdAt: d5
			},
			{
				id: "pu-3",
				date: d1,
				productId: p6.id,
				productName: p6.name,
				quantity: 15,
				unit: p6.unit,
				purchasePrice: p6.purchasePrice,
				total: 15 * p6.purchasePrice,
				supplier: "স্থানীয় খৈল মিল",
				paid: Math.round(15 * p6.purchasePrice * .5),
				createdAt: d1
			}
		],
		expenses: [
			{
				id: "e-1",
				date: d5,
				category: "ভাড়া",
				amount: 8e3,
				kind: "shop",
				note: "দোকান ভাড়া",
				createdAt: d5
			},
			{
				id: "e-2",
				date: d2,
				category: "বিদ্যুৎ",
				amount: 1450,
				kind: "shop",
				createdAt: d2
			},
			{
				id: "e-3",
				date: today,
				category: "যাতায়াত",
				amount: 420,
				kind: "shop",
				note: "মাল আনা",
				createdAt: today
			},
			{
				id: "e-4",
				date: d1,
				category: "মালিকের উত্তোলন",
				amount: 5e3,
				kind: "owner",
				createdAt: d1
			}
		],
		collections: [
			{
				id: "col-1",
				date: d5,
				partyId: "c-1",
				partyName: "করিম মিয়া",
				kind: "customer",
				amount: 4e3,
				method: "নগদ",
				createdAt: d5
			},
			{
				id: "col-2",
				date: d1,
				partyId: "c-2",
				partyName: "আবদুল মালেক",
				kind: "customer",
				amount: 3e3,
				method: "বিকাশ",
				createdAt: d1
			},
			{
				id: "col-3",
				date: today,
				partyId: "c-1",
				partyName: "করিম মিয়া",
				kind: "customer",
				amount: 2500,
				method: "নগদ",
				createdAt: today
			}
		],
		orders: [{
			id: "o-1",
			customerId: "c-1",
			customerName: "করিম মিয়া",
			items: [{
				productId: p1.id,
				productName: p1.name,
				unit: p1.unit,
				quantity: 3,
				salePrice: p1.salePrice,
				total: 3 * p1.salePrice
			}, {
				productId: p7.id,
				productName: p7.name,
				unit: p7.unit,
				quantity: 2,
				salePrice: p7.salePrice,
				total: 2 * p7.salePrice
			}],
			total: 3 * p1.salePrice + 2 * p7.salePrice,
			status: "pending",
			note: "কাল সকালে লাগবে",
			createdAt: `${today}T08:12:00`,
			updatedAt: `${today}T08:12:00`
		}, {
			id: "o-2",
			customerId: "c-3",
			customerName: "নুরুল ইসলাম",
			items: [{
				productId: p2.id,
				productName: p2.name,
				unit: p2.unit,
				quantity: 2,
				salePrice: p2.salePrice,
				total: 2 * p2.salePrice
			}],
			total: 2 * p2.salePrice,
			status: "accepted",
			createdAt: `${d1}T16:40:00`,
			updatedAt: `${d1}T17:05:00`
		}],
		adjustments: [],
		billSeq: 1050
	};
}
function canManage(role) {
	return role === "owner" || role === "manager";
}
function canSeeProfit(role) {
	return role === "owner" || role === "manager";
}
function roleLabel(role) {
	switch (role) {
		case "owner": return "মালিক";
		case "manager": return "ব্যবস্থাপক";
		case "salesman": return "সেলস ম্যান";
		case "customer": return "ক্রেতা";
		default: return "";
	}
}
var seed = createSeed();
var useShop = create()(persist((set, get) => ({
	hydrated: false,
	user: null,
	loginError: "",
	products: seed.products,
	customers: seed.customers,
	sales: seed.sales,
	purchases: seed.purchases,
	expenses: seed.expenses,
	collections: seed.collections,
	orders: seed.orders,
	adjustments: seed.adjustments,
	billSeq: seed.billSeq,
	setHydrated: (v) => set({ hydrated: v }),
	login: (phone, password) => {
		const identity = phone.trim();
		const acc = DEMO_ACCOUNTS.find((a) => a.phone === identity || a.name === identity);
		if (!acc || acc.password !== password) {
			set({ loginError: "আইডি বা পাসওয়ার্ড ভুল হয়েছে" });
			return false;
		}
		set({
			user: {
				id: acc.id,
				name: acc.name,
				phone: acc.phone,
				role: acc.role,
				customerId: "customerId" in acc ? acc.customerId : void 0
			},
			loginError: ""
		});
		return true;
	},
	logout: () => set({
		user: null,
		loginError: ""
	}),
	resetDemo: () => {
		const next = createSeed();
		set({
			products: next.products,
			customers: next.customers,
			sales: next.sales,
			purchases: next.purchases,
			expenses: next.expenses,
			collections: next.collections,
			orders: next.orders,
			adjustments: next.adjustments,
			billSeq: next.billSeq
		});
	},
	addCustomer: (c) => {
		const row = {
			...c,
			id: nid("c"),
			createdAt: todayKey()
		};
		set((s) => ({ customers: [row, ...s.customers] }));
		return row;
	},
	updateCustomer: (id, patch) => set((s) => ({ customers: s.customers.map((c) => c.id === id ? {
		...c,
		...patch
	} : c) })),
	addProduct: (p) => {
		const row = {
			...p,
			id: nid("p"),
			createdAt: todayKey()
		};
		set((s) => ({ products: [row, ...s.products] }));
		return row;
	},
	updateProduct: (id, patch) => set((s) => ({ products: s.products.map((p) => p.id === id ? {
		...p,
		...patch
	} : p) })),
	addSale: (input) => {
		const subtotal = input.items.reduce((a, i) => a + i.total, 0);
		const total = Math.max(0, subtotal - input.discount);
		const paid = Math.min(Math.max(0, input.paid), total);
		const billNo = `বিল-${bnNum(get().billSeq)}`;
		const row = {
			id: nid("s"),
			billNo,
			date: input.date,
			items: input.items,
			subtotal,
			discount: input.discount,
			total,
			paid,
			customerId: input.customerId,
			customerName: input.customerName,
			createdBy: get().user?.name ?? "দোকান",
			note: input.note,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({
			sales: [row, ...s.sales],
			billSeq: s.billSeq + 1
		}));
		return row;
	},
	addPurchase: (input) => {
		const row = {
			...input,
			id: nid("pu"),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({ purchases: [row, ...s.purchases] }));
		return row;
	},
	addExpense: (input) => {
		const row = {
			...input,
			id: nid("e"),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({ expenses: [row, ...s.expenses] }));
		return row;
	},
	addCollection: (input) => {
		const row = {
			...input,
			id: nid("col"),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({ collections: [row, ...s.collections] }));
		return row;
	},
	addAdjustment: (input) => {
		const row = {
			...input,
			id: nid("adj"),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({ adjustments: [row, ...s.adjustments] }));
	},
	addOrder: (input) => {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const row = {
			...input,
			id: nid("o"),
			status: "pending",
			createdAt: now,
			updatedAt: now
		};
		set((s) => ({ orders: [row, ...s.orders] }));
		return row;
	},
	setOrderStatus: (id, status) => set((s) => ({ orders: s.orders.map((o) => o.id === id ? {
		...o,
		status,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	} : o) })),
	fulfillOrder: (id) => {
		const order = get().orders.find((o) => o.id === id);
		if (!order || order.status === "delivered" || order.status === "cancelled") return null;
		const items = order.items.map((i) => {
			const p = get().products.find((x) => x.id === i.productId);
			return {
				productId: i.productId,
				productName: i.productName,
				unit: i.unit,
				quantity: i.quantity,
				salePrice: i.salePrice,
				purchasePrice: p?.purchasePrice ?? 0,
				total: i.total
			};
		});
		const sale = get().addSale({
			date: todayKey(),
			items,
			discount: 0,
			paid: 0,
			customerId: order.customerId,
			customerName: order.customerName,
			note: `অর্ডার ${order.id.slice(-4)}`
		});
		get().setOrderStatus(id, "delivered");
		return sale;
	},
	productStock: (id) => {
		const p = get().products.find((x) => x.id === id);
		if (!p) return 0;
		return stockOf(p, get().sales, get().purchases, get().adjustments);
	},
	dueOf: (customerId) => customerDue(customerId, get().sales, get().collections)
}), {
	name: "karnaphuli-shopledger-v1",
	partialize: (s) => {
		const { hydrated, loginError, ...rest } = s;
		return rest;
	},
	onRehydrateStorage: () => () => {
		useShop.setState({ hydrated: true });
	}
}));
if (typeof window !== "undefined") {
	useShop.persist.rehydrate();
	if (!useShop.persist.hasHydrated()) window.setTimeout(() => {
		if (!useShop.getState().hydrated) useShop.setState({ hydrated: true });
	}, 80);
	else useShop.setState({ hydrated: true });
}
//#endregion
export { bnNum as a, customerDue as c, profitSummary as d, roleLabel as f, useShop as g, todayKey as h, bnDate as i, money as l, supplierDue as m, SHOP as n, canManage as o, stockOf as p, allCustomerDues as r, canSeeProfit as s, DEMO_ACCOUNTS as t, monthStartKey as u };
