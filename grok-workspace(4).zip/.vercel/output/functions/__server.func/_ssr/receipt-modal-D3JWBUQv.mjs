import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bnNum, i as bnDate, l as money, n as SHOP } from "./store-BntNszej.mjs";
import { l as Share2, t as X, w as Download } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/receipt-modal-D3JWBUQv.js
var import_jsx_runtime = require_jsx_runtime();
function ReceiptModal({ sale, onClose }) {
	const due = sale.total - sale.paid;
	const share = async () => {
		const lines = [
			SHOP.name,
			SHOP.tagline,
			`${sale.billNo} • ${bnDate(sale.date)}`,
			`ক্রেতা: ${sale.customerName}`,
			...sale.items.map((i) => `${i.productName} × ${bnNum(i.quantity)} = ${money(i.total)}`),
			`মোট: ${money(sale.total)}`,
			`জমা: ${money(sale.paid)}`,
			`বাকি: ${money(due)}`,
			SHOP.phones.join(", ")
		].join("\n");
		if (navigator.share) try {
			await navigator.share({
				title: sale.billNo,
				text: lines
			});
			return;
		} catch {}
		await navigator.clipboard.writeText(lines);
	};
	const download = () => {
		const blob = new Blob([`<html><head><meta charset="utf-8"><title>${sale.billNo}</title></head><body style="font-family:sans-serif;padding:24px">${document.getElementById("receipt-sheet")?.innerHTML ?? ""}</body></html>`], { type: "text/html" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `${sale.billNo}.html`;
		a.click();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-fg/50 p-3 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[92dvh] w-full max-w-md overflow-y-auto rounded-xl bg-card shadow-card",
			onClick: (e) => e.stopPropagation(),
			role: "dialog",
			"aria-labelledby": "receipt-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "receipt-title",
						className: "font-semibold text-primary-dark",
						children: "বিক্রয় রসিদ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "বন্ধ",
						onClick: onClose,
						className: "rounded-full p-1.5 hover:bg-mint",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: "receipt-sheet",
					className: "px-5 py-5 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: SHOP.logo,
							alt: "",
							className: "mx-auto mb-2 size-14 rounded-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-bold",
							children: SHOP.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: SHOP.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px] text-muted",
							children: SHOP.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: SHOP.phones.join(" • ")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 border-t border-dashed border-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sale.billNo }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bnDate(sale.date) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-left text-sm font-medium",
							children: ["ক্রেতা: ", sale.customerName]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "mt-3 w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 font-medium",
										children: "পণ্য"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right font-medium",
										children: "পরিমাণ"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right font-medium",
										children: "মোট"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sale.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line/70",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 pr-2",
										children: i.productName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1.5 text-right tabular",
										children: [
											bnNum(i.quantity),
											" ",
											i.unit
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 text-right tabular",
										children: money(i.total)
									})
								]
							}, i.productId + i.productName)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "উপমোট",
									v: money(sale.subtotal)
								}),
								sale.discount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "ছাড়",
									v: money(sale.discount)
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "সর্বমোট",
									v: money(sale.total),
									bold: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "জমা",
									v: money(sale.paid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "বাকি",
									v: money(due),
									bold: due > 0
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-[11px] text-muted",
							children: "মালিকের স্বাক্ষর ____________________"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 border-t border-line p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void share(),
						className: "flex flex-1 items-center justify-center gap-2 rounded-md bg-primary py-3 text-sm font-semibold text-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { size: 16 }), " শেয়ার"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: download,
						className: "flex items-center justify-center gap-2 rounded-md border border-line px-4 py-3 text-sm font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 16 })
					})]
				})
			]
		})
	});
}
function Row({ k, v, bold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between ${bold ? "font-bold" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular",
			children: v
		})]
	});
}
//#endregion
export { ReceiptModal as t };
